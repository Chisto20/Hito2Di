// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  firebaseConfig: {
    apiKey: "AIzaSyDEDDgzvi9u4fRRwtOwV6g-4l-stols6EI",
    authDomain: "database-hito2.firebaseapp.com",
    databaseURL: "https://database-hito2.firebaseio.com",
    projectId: "database-hito2",
    storageBucket: "database-hito2.appspot.com",
    messagingSenderId: "833538159204",
    appId: "1:833538159204:web:79c9b3459a91299c562571",
    measurementId: "G-MVDVMNHX23"
  }
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
