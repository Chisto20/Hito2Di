import { Component, OnInit } from '@angular/core';
import { Alumnos } from '../models/alumnos';

@Component({
  selector: 'app-lista',
  templateUrl: './lista.component.html',
  styleUrls: ['./lista.component.css']
})
export class ListaComponent implements OnInit {

  alumnoArray: Alumnos[] = [
    { id: 1, tel: 654844978, name: "Mery", ayuda: "Integracion Social" },
    { id: 2, tel: 677786682, name: "Pedro", ayuda: "Matematicas" },
    { id: 3, tel: 707688687, name: "Alvaro", ayuda: "Lengua" },
    { id: 4, tel: 677768672, name: "Miguel", ayuda: "Sociales" }
  ];

  constructor() { }

  ngOnInit() {
    
  }

}
