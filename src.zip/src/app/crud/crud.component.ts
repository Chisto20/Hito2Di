import { Component, OnInit } from '@angular/core';
import { Alumnos } from '../models/alumnos';

@Component({
  selector: 'app-crud',
  templateUrl: './crud.component.html',
  styleUrls: ['./crud.component.css']
})
export class CrudComponent implements OnInit {

  alumnoArray: Alumnos[] = [
    { id: 1, tel: 654844978, name: "Mery", ayuda: "Integracion Social" },
    { id: 2, tel: 677786682, name: "Pedro", ayuda: "Matematicas" },
    { id: 3, tel: 707688687, name: "Alvaro", ayuda: "Lengua" },
    { id: 4, tel: 677768672, name: "Miguel", ayuda: "Sociales" }
  ];

  selectAlumno: Alumnos = new Alumnos();

  constructor() { }

  ngOnInit() {
  }

  addedit() {
    if (this.selectAlumno.id === 0) {
      this.selectAlumno.id = this.alumnoArray.length + 1;
      this.alumnoArray.push(this.selectAlumno);
    }
    this.selectAlumno = new Alumnos();

  }

  openEdit(alumno: Alumnos) {
    this.selectAlumno = alumno;
  }

  borrar(){
    if(confirm('¿Seguro?')){
      this.alumnoArray = this.alumnoArray.filter(x => x != this.selectAlumno);
    this.selectAlumno = new Alumnos();
    }
  }
}
