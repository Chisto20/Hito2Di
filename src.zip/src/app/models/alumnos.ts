export class Alumnos {
    id: number = 0;
    tel: number;
    name: string;
    ayuda: string;
}
