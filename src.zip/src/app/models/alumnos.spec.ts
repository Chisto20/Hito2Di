import { Alumnos } from './alumnos';

describe('Alumnos', () => {
  it('should create an instance', () => {
    expect(new Alumnos()).toBeTruthy();
  });
});
